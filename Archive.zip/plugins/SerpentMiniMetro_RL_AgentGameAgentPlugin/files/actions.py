# plugins/SerpentMiniMetroGameAgentPlugin/actions.py
from enum import IntEnum

class Action(IntEnum):
    #Main Title
    PRESS_PLAY = 0 #Main title to get into map selection
    SELECT_NEXT_MAP = 1 #Select map to navigate to other maps
    SELECT_MAP = 2 #Select map to play
    #In Game Mechanics

    #Time Control
    PRESS_CLOCK = 3
    PRESS_PAUSE = 4
    PRESS_SPEED_ONE = 5
    PRESS_SPEED_TWO = 6

    #Game Controls
    #Initiating a new line
    SELECT_STATION = 7   # left-click on a station icon: Used for initiating a new line

    #Deleting a line
    SELECT_LINE_MENU = 8
    SELECT_LINE = 9
    DELETE_LINE = 10
    #Modifying existing lines： Extending one end of the metro line
    SELECT_LINE_END = 11

    #In-game plays
    # Selecting stuff from the reserve pool
    SELECT_TRAIN = 12
    SELECT_CARRIAGE = 13
    SELECT_HUB = 14
    SELECT_SHINKANSEN = 15

    #Dragging stuff from reserve pool to the map
    DRAG_TRAIN_TO_LINE = 16
    DRAG_CARRIAGE_TO_LINE = 17
    DRAG_HUB_TO_STATION = 18
    DRAG_SHINKANSEN_TO_LINE = 19

    #Used for saving near-exploding train stations
    DRAG_TRAIN_TO_STATION = 20
    DRAG_CARRIAGE_TO_STATION = 21

    # drag track to some station
    #Two use cases: 1. Add an intermediate station in a line 2. Remove an intermediate station in a line
    #Commonly used as select line_end
    DRAG_TRACK_TO_STATION = 22


    #Game Rewards
    #For specific maps like Osaka, each week will give you 2 choices: train/shinkansen and some other upgrades.
    #However, for normal maps, the first selection is really just getting another train.
    SELECT_REWARD_ONE_TRAIN = 23   # hit Space to accept upgrade
    SELECT_REWARD_ONE_SHINKANSEN = 24
    SELECT_REWARD_TWO_HUB = 25 #Selecting whatever the week offers.
    SELECT_REWARD_TWO_ONE_BRIDGE = 26
    SELECT_REWARD_TWO_TWO_BRIDGE = 27
    SELECT_REWARD_LINE = 28
    SELECT_REWARD_CARRIAGE = 29
    #Game Over
    PRESS_RESTART = 30
    PRESS_MAIN_MENU = 31

    #Placeholder
    NO_OP = 32


