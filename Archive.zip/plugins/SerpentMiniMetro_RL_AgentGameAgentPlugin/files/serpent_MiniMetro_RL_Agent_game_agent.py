from serpent.game_agent import GameAgent
from .recorder import CSVActionRecorder

class SerpentMiniMetro_RL_AgentGameAgent(GameAgent):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.frame_handlers["PLAY"] = self.handle_play

        self.frame_handler_setups["PLAY"] = self.setup_play

        # register new frame handler
        self.frame_handler_setups["learn"] = self.setup_learn
        self.frame_handlers["learn"] = self.handle_learn

    def setup_play(self):
        pass

    def handle_play(self, game_frame):
        pass

    # ------------------------------------------------------------
    #  Called once before the first frame arrives
    def setup_learn(self):
        self.logger = CSVActionRecorder("datasets/inputs_mm.csv")

    # ------------------------------------------------------------
    #  Called every captured frame (2 fps in your config)
    def handle_learn(self, game_frame):
        """
        We don't control the game in this mode; we just let the recorder
        thread collect key/mouse events while Serpent keeps saving frames.
        """
        pass  # nothing to do per-frame

    # ------------------------------------------------------------
    def shutdown(self):
        """Serpent calls this when you press Q in the Serpent console."""
        if hasattr(self, "logger"):
            self.logger.stop()